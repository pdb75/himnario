package com.kiwi.fluttercrashlytics

class FlutterException(message: String?): Throwable(message)